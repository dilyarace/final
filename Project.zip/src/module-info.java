/**
 * 
 */
/**
 * 
 */
module InventoryManager {
}