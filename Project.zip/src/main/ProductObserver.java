package main;

// Interface for the Observer
public interface ProductObserver {
    void update(Product product);
}